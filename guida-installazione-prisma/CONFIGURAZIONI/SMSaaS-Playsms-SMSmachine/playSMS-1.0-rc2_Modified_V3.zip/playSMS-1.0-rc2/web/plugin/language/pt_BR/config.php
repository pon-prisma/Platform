<?php
$plugin_config['pt_BR']['title'] = 'Portuguese (Brazil)';
