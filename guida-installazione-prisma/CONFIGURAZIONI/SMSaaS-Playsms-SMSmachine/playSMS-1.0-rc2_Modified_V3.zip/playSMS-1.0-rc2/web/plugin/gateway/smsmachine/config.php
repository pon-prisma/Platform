<?php
defined('_SECURE_') or die('Forbidden');

$plugin_config['smsmachine']['name'] = 'smsmachine';
$plugin_config['smsmachine']['api_smsmachine']='http://MyIP_SMSmachine/smssend.cgi';
$plugin_config['smsmachine']['pwd_send']='PWD_SmsMachineForSendSMS';  
$plugin_config['smsmachine']['push_value']='0';
