<?php
defined('_SECURE_') or die('Forbidden');

// hook_sendsms
// called by main sms sender
// return true for success delivery
// $sms_sender          : sender mobile number
// $sms_footer          : sender sms footer or sms sender ID
// $sms_to              : destination sms number
// $sms_msg             : sms message to be delivered
// $uid                 : sender User ID
// $gpid                : group phonebook id (optional)
// $smslog_id           : sms ID
// $sms_type            : send flash message when the value is "flash"
// $unicode             : send unicode character (16 bit)
function smsmachine_hook_sendsms($sms_sender,$sms_footer,$sms_to,$sms_msg,$uid='',$gpid=0,$smslog_id=0,$sms_type='text',$unicode=0) {
       logger_print("Enter in function smsmachine_hook_sendsms ");
       //logger_print("Footer ".$sms_footer);

        global $plugin_config; // global all variables needed, eg: variables from config.php
        $sms_sender = stripslashes($sms_sender);
        $sms_footer = stripslashes($sms_footer);
        $sms_msg = stripslashes($sms_msg);
        $ok = false;

        if ($sms_footer) {
                $sms_msg = $sms_msg.$sms_footer;
        }

        if ($sms_sender && $sms_to && $sms_msg) {

                $unicode = "";
                if ($unicode) {
                        if (function_exists('mb_convert_encoding')) {
                                // $sms_msg = mb_convert_encoding($sms_msg, "UCS-2BE", "auto");
                                $sms_msg = mb_convert_encoding($sms_msg, "UCS-2", "auto");
                                $unicode = "&type=unicode"; // added at the of query string if unicode
                        }
                }
            
         $sms_msg = iconv("UTF-8","ISO-8859-1",$sms_msg);			
         $data_string = "Pwd=".urlencode($plugin_config['smsmachine']['pwd_send'])."&text=".urlencode($sms_msg).$unicode."&num=".urlencode($sms_to)."&Push=".$plugin_config['smsmachine']['push_value'];
                $url = $plugin_config['smsmachine']['api_smsmachine'];
                //logger_print("Url smsmachine ".$url);
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
                curl_setopt($ch, CURLOPT_TIMEOUT, 5);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);

                //execute post
                $result = curl_exec($ch);

                //close connection
               curl_close($ch);
               //logger_print($result, 3, "smsmachine result value");
               logger_print("result smsmachine ".$result);

              if (strpos($result,'errno=0&desc=SMS Queued') !== false) {
                 $ok = true;
                 $p_status = 1;
                 dlr($smslog_id,$uid,$p_status);
              }
              else {
                 $p_status = 2;
                 dlr($smslog_id,$uid,$p_status);
               }

       }
       return $ok;
}

// hook_playsmsd
// used by index.php?app=main&inc=daemon to execute custom commands
function smsmachine_hook_playsmsd() {
        // custom commands
}
// hook_getsmsstatus
// called by index.php?app=main&inc=daemon (periodic daemon) to set sms status
// no returns needed
// $p_datetime  : first sms delivery datetime
// $p_update    : last status update datetime
function smsmachine_hook_getsmsstatus($gpid=0,$uid="",$smslog_id="",$p_datetime="",$p_update="") {
        // global $tmpl_param;
        // p_status :
        // 0 = pending
        // 1 = sent
        // 2 = failed
        // 3 = delivered
        // dlr($smslog_id,$uid,$p_status);
}

// hook_getsmsinbox
// called by incoming sms processor
// no returns needed
function smsmachine_hook_getsmsinbox() {
        // global $tmpl_param;
        // $sms_datetime        : incoming sms datetime
        // $message             : incoming sms message
        // if $sms_sender and $message are not coming from $_REQUEST then you need to addslashes it
        // $sms_sender = addslashes($sms_sender);
        // $message = addslashes($message);
        // recvsms($sms_datetime,$sms_sender,$message,$sms_receiver)
        // you must retrieve all informations needed by recvsms()
        // from incoming sms, have a look gnokii gateway module
}

?>
