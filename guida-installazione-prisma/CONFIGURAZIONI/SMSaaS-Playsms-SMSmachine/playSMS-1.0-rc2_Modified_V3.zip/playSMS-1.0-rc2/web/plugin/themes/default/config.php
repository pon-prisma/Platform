<?php
defined('_SECURE_') or die('Forbidden');

// default loaded page/plugin
/*
$themes_config['default']['main'] = array(
	'default_inc' => 'feature_report',
	'default_route' => 'user',
	'default_op' => '',
);
*/

// override common action icons
/*
$themes_config['default']['icon'] = array(
	'edit' => "<span class='playsms-icon glyphicon glyphicon-cog' alt='"._('Edit')."' title='"._('Edit')."'></span>",
	'delete' => "<span class='playsms-icon glyphicon glyphicon-trash' alt='"._('Delete')."' title='"._('Delete')."'></span>",
);
*/
