<?php
defined('_SECURE_') or die('Forbidden');

if(!auth_isvalid()){auth_block();};

// empty

?>