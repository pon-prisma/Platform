#!/bin/bash

##  The information you wants to get back
##  eg: uname -a, uptime
M=`uname -nsr`

echo $M
