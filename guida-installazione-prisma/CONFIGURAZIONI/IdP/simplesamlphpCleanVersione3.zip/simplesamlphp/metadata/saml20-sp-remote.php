<?php
/**
 * SAML 2.0 remote SP metadata for simpleSAMLphp.
 *
 * See: http://simplesamlphp.org/docs/trunk/simplesamlphp-reference-sp-remote
 */






$metadata['XXXXXXXXXXXXXxx'] = array (
  'entityid' => 'XXXXXXXXXXXXXXXXxxx',
  'contacts' => 
  array (
  ),
  'metadata-set' => 'saml20-sp-remote',
  'AssertionConsumerService' => 
  array (
    0 => 
    array (
      'Binding' => 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',
      'Location' => 'https://XXXXXXXXXXXXXXXXXXXXXXXXXXXX:443/saml/SSO/alias/defaultAlias',
      'index' => 0,
      'isDefault' => true,
    ),
    1 => 
    array (
      'Binding' => 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Artifact',
      'Location' => 'https://XXXXXXXXXXXXXXXXXXXXXXXXXXXXX:443/saml/SSO/alias/defaultAlias',
      'index' => 1,
    ),
  ),
  'SingleLogoutService' => 
  array (
    0 => 
    array (
      'Binding' => 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',
      'Location' => 'https://XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX:443/saml/SingleLogout/alias/defaultAlias',
    ),
    1 => 
    array (
      'Binding' => 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect',
      'Location' => 'https://XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx:443/saml/SingleLogout/alias/defaultAlias',
    ),
  ),
  'NameIDFormat' => 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
  'keys' => 
  array (
    0 => 
    array (
      'encryption' => false,
      'signing' => true,
      'type' => 'X509Certificate',
      'X509Certificate' => 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxxxxx',
    ),
    1 => 
    array (
      'encryption' => true,
      'signing' => false,
      'type' => 'X509Certificate',
      'X509Certificate' => 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
    ),
  ),
  'validate.authnrequest' => true,
  'saml20.sign.assertion' => true,
);







