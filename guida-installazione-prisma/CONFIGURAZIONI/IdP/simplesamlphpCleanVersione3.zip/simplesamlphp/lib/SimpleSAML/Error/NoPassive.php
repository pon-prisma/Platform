<?php


class SimpleSAML_Error_NoPassive extends SimpleSAML_Error_Exception {

}

?>