<?php
/**
 * Support the htmlinject hook, which allows modules to change header, pre and post body on all pages.
 */
$this->data['htmlinject'] = array(
	'htmlContentPre' => array(),
	'htmlContentPost' => array(),
	'htmlContentHead' => array(),
);


$jquery = array();
if (array_key_exists('jquery', $this->data)) $jquery = $this->data['jquery'];

if (array_key_exists('pageid', $this->data)) {
	$hookinfo = array(
		'pre' => &$this->data['htmlinject']['htmlContentPre'], 
		'post' => &$this->data['htmlinject']['htmlContentPost'], 
		'head' => &$this->data['htmlinject']['htmlContentHead'], 
		'jquery' => &$jquery, 
		'page' => $this->data['pageid']
	);
		
	SimpleSAML_Module::callHooks('htmlinject', $hookinfo);	
}
// - o - o - o - o - o - o - o - o - o - o - o - o -

/**
 * Do not allow to frame simpleSAMLphp pages from another location.
 * This prevents clickjacking attacks in modern browsers.
 *
 * If you don't want any framing at all you can even change this to
 * 'DENY', or comment it out if you actually want to allow foreign
 * sites to put simpleSAMLphp in a frame. The latter is however
 * probably not a good security practice.
 */
header('X-Frame-Options: SAMEORIGIN');

?>


<?php
//-- PROVA
//$this->includeAtTemplateBase('includes/footer.php');

//$f=SimpleSAML_Module::getModuleURL('include/recoverPassword');
//echo $f;


//$filename = $this->findTemplatePath('include/recoverPassword');
//echo $filename;
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0" />
<script type="text/javascript" src="/<?php echo $this->data['baseurlpath']; ?>resources/script.js"></script>

<title>
PRISMA Login

<?php
/*
if(array_key_exists('header', $this->data)) {
	echo $this->data['header'];
} else {
	echo 'simpleSAMLphp';
}
*/
?>
</title>

<!--	<link rel="stylesheet" type="text/css" href="/--><?php //echo $this->data['baseurlpath']; ?> <!--resources/default.css" />-->

<!--	<link rel="stylesheet" type="text/css" href="/<?php echo $this->data['baseurlpath']; ?>resources/idpprismatema/defaultPrisma.css" /> -->
<!--	<link rel="icon" type="image/icon" href="/--><?php //echo $this->data['baseurlpath']; ?><!--resources/icons/favicon.ico" />-->
	<link rel="icon" type="image/icon" href="/<?php echo $this->data['baseurlpath']; ?>/resources/idpprismatema/iconaPrisma.ico" />

<!-- NEW CSS PRISMA PORTAL -->
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<!-- Font Awesome 4.1.0 -->
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<!-- Base theme style -->
	<link href="/<?php echo $this->data['baseurlpath']; ?>resources/idpprismatema/admin-lte.css" rel="stylesheet" type="text/css" />
	<link href="/<?php echo $this->data['baseurlpath']; ?>resources/idpprismatema/yeti-elements.css" rel="stylesheet" type="text/css" />
	<!-- Custom theme style -->
	<link href="/<?php echo $this->data['baseurlpath']; ?>resources/idpprismatema/prisma.css" rel="stylesheet" type="text/css" />
<!-- NEW CSS PRISMA PORTAL -->

<?php
/*
if(!empty($jquery)) {
	$version = '1.5';
	if (array_key_exists('version', $jquery))
		$version = $jquery['version'];
		
	if ($version == '1.5') {
		if (isset($jquery['core']) && $jquery['core'])
			echo('<script type="text/javascript" src="/' . $this->data['baseurlpath'] . 'resources/jquery.js"></script>' . "\n");
	
		if (isset($jquery['ui']) && $jquery['ui'])
			echo('<script type="text/javascript" src="/' . $this->data['baseurlpath'] . 'resources/jquery-ui.js"></script>' . "\n");
	
		if (isset($jquery['css']) && $jquery['css'])
			echo('<link rel="stylesheet" media="screen" type="text/css" href="/' . $this->data['baseurlpath'] . 
				'resources/uitheme/jquery-ui-themeroller.css" />' . "\n");	
			
	} else if ($version == '1.6') {
		if (isset($jquery['core']) && $jquery['core'])
			echo('<script type="text/javascript" src="/' . $this->data['baseurlpath'] . 'resources/jquery-16.js"></script>' . "\n");
	
		if (isset($jquery['ui']) && $jquery['ui'])
			echo('<script type="text/javascript" src="/' . $this->data['baseurlpath'] . 'resources/jquery-ui-16.js"></script>' . "\n");
	
		if (isset($jquery['css']) && $jquery['css'])
			echo('<link rel="stylesheet" media="screen" type="text/css" href="/' . $this->data['baseurlpath'] . 
				'resources/uitheme16/ui.all.css" />' . "\n");	
	}
}

if(!empty($this->data['htmlinject']['htmlContentHead'])) {
	foreach($this->data['htmlinject']['htmlContentHead'] AS $c) {
		echo $c;
	}
}

if ($this->isLanguageRTL()) {
?>
	<link rel="stylesheet" type="text/css" href="/<?php echo $this->data['baseurlpath']; ?>resources/default-rtl.css" />
<?php	
}
*/
?>
	<meta name="robots" content="noindex, nofollow" />

<?php	
/*
if(array_key_exists('head', $this->data)) {
	echo '<!-- head -->' . $this->data['head'] . '<!-- /head -->';
}
*/
?>
</head>
<?php
$onLoad = '';
if(array_key_exists('autofocus', $this->data)) {
	$onLoad .= 'SimpleSAML_focus(\'' . $this->data['autofocus'] . '\');';
}
if (isset($this->data['onLoad'])) {
	$onLoad .= $this->data['onLoad']; 
}

if($onLoad !== '') {
	$onLoad = ' onload="' . $onLoad . '"';
}
?>

<!--<body<?php /*echo $onLoad;*/ ?>>-->
<body class="skin-blue outoflayout-background">

<!--- PROVA NUOVO CSS -->
	<div class="wrapper-outoflayout">
		<section>
			<div class="row">
				<div class="col-xs-12">

					<!-- Header -->
					<header class="header-outoflayout">
						<!--
						<a href="https://prisma.cloud.reply.eu/" title="Layout pubblico">
						-->
						<h1>
							<img class="img-logo" id="logoPrisma" alt="logo PRISMA" title="PRISMA" src="/<?php echo $this->data['baseurlpath']; ?>/resources/idpprismatema/prisma-logo.png" />
							Prisma
							<span class="label label-title">
								Alpha
							</span>
						</h1>
						<!--
						</a>
						-->
					</header>
					<!-- Header -->
<!--- PROVA NUOVO CSS -->

<div id="wrap">

	<?php 	
/*
//	$includeLanguageBar = TRUE;
        $includeLanguageBar = FALSE;

	if (!empty($_POST)) 
		$includeLanguageBar = FALSE;
	if (isset($this->data['hideLanguageBar']) && $this->data['hideLanguageBar'] === TRUE) 
		$includeLanguageBar = FALSE;
	
	if ($includeLanguageBar) 
	{		
		echo '<div id="languagebar">';
		$languages = $this->getLanguageList();
		$langnames = array(
					'no' => 'Bokmål', // Norwegian Bokmål
					'nn' => 'Nynorsk', // Norwegian Nynorsk
					'se' => 'Sámegiella', // Northern Sami
					'sam' => 'Åarjelh-saemien giele', // Southern Sami
					'da' => 'Dansk', // Danish
					'en' => 'English',
					'de' => 'Deutsch', // German
					'sv' => 'Svenska', // Swedish
					'fi' => 'Suomeksi', // Finnish
					'es' => 'Español', // Spanish
					'fr' => 'Français', // French
					'it' => 'Italiano', // Italian
					'nl' => 'Nederlands', // Dutch
					'lb' => 'Lëtzebuergesch', // Luxembourgish
					'cs' => 'Čeština', // Czech
					'sl' => 'Slovenščina', // Slovensk
					'lt' => 'Lietuvių kalba', // Lithuanian
					'hr' => 'Hrvatski', // Croatian
					'hu' => 'Magyar', // Hungarian
					'pl' => 'Język polski', // Polish
					'pt' => 'Português', // Portuguese
					'pt-br' => 'Português brasileiro', // Portuguese
					'ru' => 'русский язык', // Russian
					'et' => 'eesti keel', // Estonian
					'tr' => 'Türkçe', // Turkish
					'el' => 'ελληνικά', // Greek
					'ja' => '日本語', // Japanese
					'zh' => '简体中文', // Chinese (simplified)
					'zh-tw' => '繁體中文', // Chinese (traditional)
					'ar' => 'العربية', // Arabic
					'fa' => 'پارسی', // Persian
					'ur' => 'اردو', // Urdu
					'he' => 'עִבְרִית', // Hebrew
					'id' => 'Bahasa Indonesia', // Indonesian
					'sr' => 'Srpski', // Serbian
					'lv' => 'Latviešu', // Latvian
					'ro' => 'Românește', // Romanian
		);
	
	
		$textarray = array();
		foreach ($languages AS $lang => $current) 
			{
			$lang = strtolower($lang);
			if ($current) 
			{
				$textarray[] = $langnames[$lang];
			} 
			else {
				$textarray[] = '<a href="' . htmlspecialchars(SimpleSAML_Utilities::addURLparameter(SimpleSAML_Utilities::selfURL(), array($this->languageParameterName => $lang))) . '">' .
					$langnames[$lang] . '</a>';
			}
		}
		echo join(' | ', $textarray);
		echo '</div>';

	}

*/
	?>


	<div id="content">

<!-- PROVA NUOVO CSS -->
<div class="box box-primary shadowbox">
	<div class="box-header">
		<i class="fa fa-sign-in"></i>
		<h3 class="box-title">Effettua il login tramite le credenziali PRISMA</h3>
	</div>
	<!-- ./box-header -->
	<div class="box-body">
		<div class="row">
		<!-- 
			<aside class="col-md-4">
				<div class="list-group" style="margin-bottom: 0;">
					<a href="https://prisma.cloud.reply.eu/accounting/signup" title="Richiedi un nuovo account" class="list-group-item">
						<h4 class="list-group-item-heading">Richiedi un account</h4>
						<p id="signup" class="list-group-item-text">
							Crea un account ed usufruisci dei servizi messi a disposizione della piattaforma PRISMA.
						</p>
					</a>
					
					<a href="https://prisma.cloud.reply.eu/accounting/signin" title="Effettua il login" class="list-group-item active">
						<h4 class="list-group-item-heading">Effettua il login</h4>
						<p class="list-group-item-text">Prisma rende disponibile l'accesso ai servizi mediante Single Sign On (SSO).</p>
					</a> 

					<a href="https://prisma.cloud.reply.eu/accounting/support" title="Richiedi assistenza" class="list-group-item">
						<h4 class="list-group-item-heading">Richiedi assistenza</h4>
						<p class="list-group-item-text">
							Hai problemi ad accedere alla piattaforma? Contatta l'assistenza per ricevere tutto il supporto necessario
						</p>
					</a>
				</div>
			</aside>
		-->
		
			<!--			
			<div class="col-md-8">
				<hr class="hidden-md hidden-lg" />
				<div class="alert prisma-green-alert alert-dismissable hidden-xs">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<p>
						PRISMA supporta l'autenticazione mediante <strong>Single
						Sign-On</strong>, permettendo l'accesso alla piattaforma mediante l'uso
						di Identity Provider terzi col quale è stata costituita una
						relazione di trust.
					</p>
				</div>
				-->

<!-- PROVA NUOVO CSS -->


<?php
/*
if(!empty($this->data['htmlinject']['htmlContentPre'])) 
	{
//	$i=0;
	foreach($this->data['htmlinject']['htmlContentPre'] AS $c) 
		{
//		echo $i;
//		echo  $c;
//		$i=$i+1;
		}
	}

*/
