<?php
if(!empty($this->data['htmlinject']['htmlContentPost'])) {
	foreach($this->data['htmlinject']['htmlContentPost'] AS $c) {
		echo $c;
	}
}
?>
	</div><!-- #content -->

<!--- NEW CSS PRISMA PORTAL -->

	<footer class="cols-xs-12 page-footer text-center">
		<h5>
			<strong>
				© Copyright 2014 — PON PRISMA 
				<br class="visible-xs" />
				PiattafoRme cloud Interoperabili per SMArt-government
			</strong>
		</h5>
		<p>
			<strong>Project funding:</strong> MIUR — Ministero dell'Istruzione,
			dell'Università e della Ricerca<br /> <strong>Project ID:</strong>
			D.D. n. 84/Ric del 2/03/2012, D.D. n. 255/Ric del 30/05/2012, D.D. n.
			370/Ric del 26/06/2012
		</p>
	</footer>

<!--- NEW CSS PRISMA PORTAL -->


<!--
	<div id="footer">
	PRISMA è un progetto finanziato dal MIUR – PON Ricerca e Competitività 2007-2013
	</div>
-->
	<!-- #footer -->

</div><!-- #wrap -->


<!--- NEW CSS PRISMA PORTAL -->
</div>
</div>
</section>
</div>

<!-- JavaScripts -->
<!-- jQuery library -->
<script src="https://code.jquery.com/jquery.js"></script>
<!-- Boostrap 3.2.0 scripts -->
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- Modernizr 2.7.2 library -->
<script src="https://ajax.aspnetcdn.com/ajax/modernizr/modernizr-2.7.2.js"></script>
<!-- Prisma Custom Scripts -->
<!--<script src="/static/assets/js/prisma.js"></script>-->

<!--- NEW CSS PRISMA PORTAL -->

</body>
</html>
