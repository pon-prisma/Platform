<?php
/**
 * Template to show list of configured authentication sources.
 *
 */
//$this->data['header'] = 'Test authentication sources';
$this->data['header'] = 'Autenticazione';

$this->includeAtTemplateBase('includes/header.php');
?>

<h1 id="titoloPrisma"><?php echo $this->data['header']; ?></h1>


<div id='sottotitoloPrisma'>
Autenticati al portale PRISMA come amministratore o come utente Prisma
</div>

<div id="containerPrisma">

<!--
<div style="float:left; display:block; width:150px; height:150px; background-color:#F00;"></div>
<div style="float:left; display:block; width:150px; height:150px; background-color:#FF0;"></div> 

<div id="admin">
verde
<img id="imgLogin" alt="Admin PRISMA" title="PRISMA" src="/<?php echo $this->data['baseurlpath']; ?>/resources/idpprismatema/adminPrisma.png" />
</div>

<div id="user">arancio</div>
-->

<?php
foreach ($this->data['sources'] as $id) 
{

if ($id=='admin')
{
// echo ("ADMIN is");

echo '<a class="linkPrisma"  href="?as=' . htmlspecialchars(urlencode($id)) . '">';
?>

<div id="admin">

<img id="imgLogin" alt="Admin PRISMA" title="PRISMA" src="/<?php echo $this->data['baseurlpath']; ?>/resources/idpprismatema/adminPrisma.png" />

<br/><br/>
Admin Prisma

<?php
////echo '<a class="linkPrisma"  href="?as=' . htmlspecialchars(urlencode($id)) . '"> admin </a>';
//echo '<a href="?as=' . htmlspecialchars(urlencode($id)) . '">ACCEDI COME ADMIN!' . htmlspecialchars($id) . '</a>';
?>

</div>
</a>

<?php
}
else
{
 //echo("non admin");

echo '<a  href="?as=' . htmlspecialchars(urlencode($id)) . '">';
?>

<div id="user">

<img id="imgLogin" alt="Admin PRISMA" title="PRISMA" src="/<?php echo $this->data['baseurlpath']; ?>/resources/idpprismatema/userPrisma.png" />

<br/><br/>
Utente Prisma

<?php
////echo '<a  href="?as=' . htmlspecialchars(urlencode($id)) . '">Utente Prisma </a>';

//echo '<a href="?as=' . htmlspecialchars(urlencode($id)) . '">ACCEDI COME ADMIN!' . htmlspecialchars($id) . '</a>';

?>

</div>

</a>

<?php
}

?>

<?php
//echo '<li><a href="?as=' . htmlspecialchars(urlencode($id)) . '">' . htmlspecialchars($id) . '</a></li>';
}
?>
<!--</ul>-->

</div>

<?php
$this->includeAtTemplateBase('includes/footer.php');
?>
