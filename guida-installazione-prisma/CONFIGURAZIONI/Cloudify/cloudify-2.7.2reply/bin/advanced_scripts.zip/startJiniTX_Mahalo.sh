#!/bin/bash
# 		JTX_JAVA_OPTIONS 	- Extended java options that are proprietary defined  for Jini Transaction Manager such as heap size, system properties or other JVM arguments that can be passed to the JVM command line. 
#							- These settings can be overridden externally to this script.

echo Starting a Mahalo Jini Transaction Manager instance

`dirname $0`/gs.sh start \"TM\" $*
