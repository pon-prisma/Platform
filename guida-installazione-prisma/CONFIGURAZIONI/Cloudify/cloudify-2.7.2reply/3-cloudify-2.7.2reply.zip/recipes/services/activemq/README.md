# ActiveMQ       

**Status**: **Under Construction**   
**Description**:  ActiveMQ        
**Maintainer**:       Cloudify  
**Maintainer email**: cloudifysource@gigaspaces.com  
**Contributors**:    [Uri Cohen](https://github.com/uric)  
**Homepage**:   [http://www.cloudifysource.org](http://www.cloudifysource.org)  
**License**:      Apache 2.0   
**Release Date**:  *Under Construction*  

Synopsis
--------

This folder contains a service recipe for ActiveMQ, which is an open source messaging and Integration Patterns server.

* Note that this recipe is under construction. We will test it and release it asap.
