# HSQLDB     

**Status**: **Under Construction**   
**Description**:  HSQLDB      
**Maintainer**:       Cloudify  
**Maintainer email**: cloudifysource@gigaspaces.com  
**Contributors**:    [Uri Cohen](https://github.com/uric)  
**Homepage**:   [http://www.cloudifysource.org](http://www.cloudifysource.org)  
**License**:      Apache 2.0   
**Release Date**:  *Under Construction*  

Synopsis
--------

This folder contains a service recipe for HSQLDB (HyperSQL Database), which is a relational database engine written in Java. 

* Note that this recipe is under construction. We will test it and release it asap.
