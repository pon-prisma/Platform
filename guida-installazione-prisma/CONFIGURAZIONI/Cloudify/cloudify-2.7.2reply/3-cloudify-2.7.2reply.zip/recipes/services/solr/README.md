# Solr   

**Status**: **Under Construction**   
**Description**:  Solr       
**Maintainer**:       Cloudify  
**Maintainer email**: cloudifysource@gigaspaces.com  
**Contributors**:    [Uri Cohen](https://github.com/uric)  
**Homepage**:   [http://www.cloudifysource.org](http://www.cloudifysource.org)  
**License**:      Apache 2.0   
**Release Date**:  *Under Construction*  

Synopsis
--------

This folder contains a service recipe for Solr, which is an open source enterprise search platform from the Apache Lucene project.

* Note that this recipe is under construction. We will test it and release it asap.
