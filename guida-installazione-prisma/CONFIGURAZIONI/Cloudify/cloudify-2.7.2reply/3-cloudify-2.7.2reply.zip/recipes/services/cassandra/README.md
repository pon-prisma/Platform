# Cassandra      

**Status**: **Under Construction**   
**Description**:  Cassandra       
**Maintainer**:       Cloudify  
**Maintainer email**: cloudifysource@gigaspaces.com  
**Contributors**:    [Uri Cohen](https://github.com/uric)  
**Homepage**:   [http://www.cloudifysource.org](http://www.cloudifysource.org)  
**License**:      Apache 2.0   
**Release Date**:  July 2nd 2013  



Tested on:
--------

* <strong>EC2 Linux</strong> 
.
* <strong>OpenStack Linux</strong> 
.
* <strong>Rackspace Linux</strong>



Synopsis
--------

This folder contains a service recipe for Cassandra, which is a highly scalable, eventually consistent, distributed, structured key-value store.


