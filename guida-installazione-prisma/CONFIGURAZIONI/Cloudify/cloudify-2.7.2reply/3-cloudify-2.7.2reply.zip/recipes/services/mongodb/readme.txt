===============================
=== Cloudify MongoDB Recipe ===
===============================

This recipe deployes the MongoDB unto your cloud,
the services must be installed in the following order:
	1. mongod
	2. mongoConfig
	3. mongos
