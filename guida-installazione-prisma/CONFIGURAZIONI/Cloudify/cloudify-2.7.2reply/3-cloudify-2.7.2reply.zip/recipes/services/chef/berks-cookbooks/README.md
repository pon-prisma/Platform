= Berkshelf installation cookbooks
Cookbooks for installation of ruby and Berkshelf gem on target nodes.
Please note the cookbooks are git submodule, in order to fetch them you need to run:
    git submodule init && git submodule update

Or use `--recursive` in your clone command
