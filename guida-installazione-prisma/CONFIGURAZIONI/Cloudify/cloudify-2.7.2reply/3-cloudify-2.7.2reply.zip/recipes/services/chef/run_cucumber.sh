#!/bin/sh
cd /home/ubuntu/cucumber
jruby -S cucumber
