default['cloudify-tester']['cucumber_dir'] = "/home/ubuntu/cucumber/features"
