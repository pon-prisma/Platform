name "app"
description "travel appserver with tomcat"
run_list "recipe[travel]"
