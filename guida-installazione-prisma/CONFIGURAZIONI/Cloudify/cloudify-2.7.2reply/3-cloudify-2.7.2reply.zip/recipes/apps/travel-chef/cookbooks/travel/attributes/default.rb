default["travel"]["db_name"] = "travel"
default["travel"]["db_user"] = "travel"
default["travel"]["db_pass"] = "test"

default["travel"]["war_directory"] = "/opt/travel"
default["travel"]["war_name"] = "travel.war"
default["travel"]["war_url"] = "https://s3-eu-west-1.amazonaws.com/gigaspaces-repository-eu/org/cloudifysource/sample-apps/travel.war"
default["travel"]["war_checksum"] = "a7325aa316663cd2b9c4bf8d964114b50da889216f83c6be9fcc2405ca837096"
