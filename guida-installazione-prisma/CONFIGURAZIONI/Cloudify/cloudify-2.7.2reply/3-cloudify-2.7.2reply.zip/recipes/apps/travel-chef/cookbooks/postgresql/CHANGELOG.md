## v0.99.4:

* [COOK-421] - config template is malformed
* [COOK-956] - add make package on ubuntu/debian

## v0.99.2:

* [COOK-916] - use < (with float) for version comparison.

## v0.99.0:

* Better support for Red Hat-family platforms
* Integration with database cookbook
* Make sure the postgres role is updated with a (secure) password
