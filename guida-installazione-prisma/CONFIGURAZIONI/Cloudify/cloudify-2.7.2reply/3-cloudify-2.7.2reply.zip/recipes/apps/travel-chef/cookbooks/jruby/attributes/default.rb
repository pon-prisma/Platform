default[:jruby][:version] = "1.6.7.2"
default[:jruby][:checksum] = "1e520f1b5130114464e5f1950cb24774"
default[:jruby][:install_path] = "/usr/local/lib/jruby"
default[:jruby][:gems] = []
default[:jruby][:nailgun] = false

