maintainer       "Andrew Crump"
maintainer_email "andrew@kotirisoftware.com"
license          "Apache 2.0"
description      "Acceptance tests for mysql"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.1.0"

depends          "database"
depends          "yum"
