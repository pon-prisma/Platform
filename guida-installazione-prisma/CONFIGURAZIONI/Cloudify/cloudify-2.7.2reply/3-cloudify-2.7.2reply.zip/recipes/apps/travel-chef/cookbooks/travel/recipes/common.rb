if node["platform_family"] == "debian"
  include_recipe "apt"
end
