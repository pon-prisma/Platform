default['mysql']['percona']['apt_key_id'] = 'CD2EFD2A'
default['mysql']['percona']['apt_uri'] = "http://repo.percona.com/apt"
default['mysql']['percona']['apt_keyserver'] = "keys.gnupg.net"
