# The Spring Travel application 

This application is composed of a Chef-server installation that loads the Chef with the relevant cookbooks once it's installed, and from a mysql and tomcat services. 
The recipes use Chef for installation and then define Cloudify specific monitoring and auto scaling on top of it. 

