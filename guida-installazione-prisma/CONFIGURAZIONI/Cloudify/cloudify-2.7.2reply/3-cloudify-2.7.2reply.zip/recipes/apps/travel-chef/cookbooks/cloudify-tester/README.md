Description
===========
This cookbook is a first step to implementing cucumber testing of applications deployed on cloudify via chef.

Requirements
============

Attributes
==========

Usage
=====

